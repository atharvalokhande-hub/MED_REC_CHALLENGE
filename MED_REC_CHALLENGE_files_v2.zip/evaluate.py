import pandas as pd
import os
import importlib.util

df = pd.read_csv("data/dataset.csv")

TEST_DRUGS = df["brand_name"].dropna().sample(5, random_state=42).tolist()

lb = pd.read_csv("leaderboard.csv")

submission_files = os.listdir("submissions")
submission_files = [f for f in submission_files if f.endswith(".py")]

if not submission_files:
    print("No submissions found.")
    exit()

latest_file = max(
    submission_files,
    key=lambda x: os.path.getctime(os.path.join("submissions", x))
)

username = latest_file.replace(".py", "")

spec = importlib.util.spec_from_file_location("submission", f"submissions/{latest_file}")
submission = importlib.util.module_from_spec(spec)
spec.loader.exec_module(submission)

if not hasattr(submission, "get_recommendations"):
    print("Function not found!")
    exit()

user_func = submission.get_recommendations

score = 0
total = len(TEST_DRUGS)

for drug in TEST_DRUGS:
    try:
        result = user_func(df.copy(), drug)

        if result is None or result.empty:
            continue

        if "price_inr" in result.columns:
            if result["price_inr"].is_monotonic_increasing:
                score += 1

    except Exception as e:
        print(f"Error for {drug}: {e}")

final_score = score / total

lb = lb[lb["username"] != username]
lb.loc[len(lb)] = [username, round(final_score, 4)]

lb = lb.sort_values(by="score", ascending=False)
lb.to_csv("leaderboard.csv", index=False)

print(f"{username} Score: {final_score}")
