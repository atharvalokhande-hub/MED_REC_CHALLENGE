import pandas as pd

def get_recommendations(df, brand_name, top_n=10):
    brand_name = str(brand_name).strip()

    if brand_name not in df["brand_name"].values:
        return None

    input_drug = df[df["brand_name"] == brand_name].iloc[0]

    alternatives = df[
        (df["primary_ingredient"] == input_drug["primary_ingredient"]) &
        (df["primary_strength"] == input_drug["primary_strength"]) &
        (df["dosage_form"] == input_drug["dosage_form"]) &
        (df["brand_name"] != brand_name)
    ].copy()

    if alternatives.empty:
        return None

    alternatives = alternatives.sort_values(by="price_inr", ascending=True)

    alternatives["savings_inr"] = (
        input_drug["price_inr"] - alternatives["price_inr"]
    ).round(2)

    alternatives["savings_percent"] = (
        (alternatives["savings_inr"] / input_drug["price_inr"]) * 100
    ).round(2)

    return alternatives.head(top_n)
